﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mathematics.AlgebraicStructures
{
    internal class VariableFactor : WithDegreeFactor
    {
        private int degree = 1;
        private string variableName;

        public VariableFactor(string variable)
        {
            this.variableName = variable;
        }

        public VariableFactor(string variable, int degree)
            : this(variable)
        {
            this.degree = degree;
        }

        public override int Degree
        {
            get { return degree; }
            set { degree = value; }
        }

        public string VariableName
        {
            get { return variableName; }
            set { variableName = value; }
        }

        public override GenericFactorType FactorType
        {
            get { return GenericFactorType.VARIABLE; }
        }

        public override int Compare(GenericFactor factor)
        {
            int res = base.Compare(factor);
            if (res == 0)
            {
                var innerFactor = factor as VariableFactor;
                if (innerFactor == null)
                {
                    return 1;
                }

                res = Comparer<string>.Default.Compare(this.variableName, innerFactor.variableName);
            }

            return res;
        }

        public override bool Equals(object obj)
        {
            var innerObj = obj as VariableFactor;
            if (innerObj == null)
            {
                return false;
            }

            return this.variableName == innerObj.variableName && this.degree == innerObj.degree;
        }

        public override int GetHashCode()
        {
            return (this.variableName.GetHashCode() ^ this.degree.GetHashCode()).GetHashCode();
        }

        public override string ToString()
        {
            if (this.degree == 1)
            {
                return this.variableName;
            }

            if (this.degree != 1)
            {
                return string.Format("{0}^{1}", this.variableName, this.degree);
            }
            else
            {
                return string.Format("{0}", this.variableName);
            }
        }
    }
}
