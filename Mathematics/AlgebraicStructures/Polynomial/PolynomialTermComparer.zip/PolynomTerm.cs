﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utilities.Collections;

namespace Mathematics.AlgebraicStructures
{
    internal class PolynomTerm<T, R>
        where R : IRing<T>
    {
        private R ring;
        private InsertionSortedCollection<GenericFactor> factors = new InsertionSortedCollection<GenericFactor>(new GenericFactorComparer(), false);

        public PolynomTerm(R ring)
        {
            this.ring = ring;
        }

        public T Coefficient
        {
            get
            {
                if (this.factors.Count == 0)
                {
                    return this.ring.AdditiveUnity;
                }

                var coeff = (from factor in this.factors
                             where factor.FactorType == GenericFactorType.COEFFICIENT
                             select factor as CoefficientFactor<T>).FirstOrDefault();

                if (coeff == null)
                {
                    return this.ring.MultiplicativeUnity;
                }

                return coeff.Coefficient;
            }
        }

        internal bool IsCoefficient
        {
            get
            {
                foreach (var factor in this.factors)
                {
                    if (factor.FactorType != GenericFactorType.COEFFICIENT)
                    {
                        return false;
                    }
                }

                return true;
            }
        }

        internal InsertionSortedCollection<GenericFactor> Factors
        {
            get
            {
                return this.factors;
            }
        }

        public void Multiply(GenericFactor factor)
        {
            switch (factor.FactorType)
            {
                case GenericFactorType.COEFFICIENT:
                    this.Multiply(factor as CoefficientFactor<T>);
                    break;
                case GenericFactorType.POLYNOMIAL:
                    this.Multiply(factor as PolynomialFactor<T, R>);
                    break;
                case GenericFactorType.VARIABLE:
                    this.Multiply(factor as VariableFactor);
                    break;
                default:
                    throw new MathematicsException(string.Format(
                        "Error in polynomial factor. Unknown factor type {0}.",
                        factor.FactorType));
            }
        }

        public void Multiply(CoefficientFactor<T> factor)
        {
            if (!factor.Coefficient.Equals(this.ring.MultiplicativeUnity))
            {
                if (this.factors.Count > 0)
                {
                    var coefficientFactor = this.factors.First;
                    if (coefficientFactor.FactorType == GenericFactorType.COEFFICIENT)
                    {
                        var innerCoefficientFactor = coefficientFactor as CoefficientFactor<T>;
                        innerCoefficientFactor.Coefficient = this.ring.Multiply(innerCoefficientFactor.Coefficient, factor.Coefficient);
                        if (innerCoefficientFactor.Coefficient.Equals(this.ring.MultiplicativeUnity))
                        {
                            this.factors.RemoveElement(coefficientFactor);
                        }
                    }
                    else
                    {
                        if (!factor.Coefficient.Equals(this.ring.MultiplicativeUnity))
                        {
                            this.factors.InsertSortElement(factor);
                        }
                    }
                }
                else
                {
                    this.factors.InsertSortElement(factor);
                }
            }
        }

        public void Multiply(Polynomial<T, R> factor)
        {
            CoefficientFactor<T> polynomialCoeffFactor = new CoefficientFactor<T>(this.ring.MultiplicativeUnity);
            if (factor.TryGetAsCoefficient(out polynomialCoeffFactor))
            {
                this.Multiply(polynomialCoeffFactor);
            }
            else
            {
                VariableFactor polynomialVariableFactor = null;
                if (factor.TryGetAsVariable(out polynomialVariableFactor))
                {
                    this.Multiply(polynomialVariableFactor);
                }
                else
                {
                    this.Multiply(factor);
                }
            }
        }

        public void Multiply(WithDegreeFactor factor)
        {
            var innerFactors = this.factors.GetEqualsTo(factor);
            if (innerFactors.MoveNext())
            {
                (innerFactors.Current as WithDegreeFactor).Degree += factor.Degree;
            }
            else
            {
                this.factors.InsertSortElement(factor);
            }
        }

        public int Compare(PolynomTerm<T, R> right)
        {
            var thisEnumerator = this.factors.GetEnumerator();
            var rightEnumerator = right.factors.GetEnumerator();
            while (thisEnumerator.MoveNext() && rightEnumerator.MoveNext())
            {
                int res = thisEnumerator.Current.Compare(rightEnumerator.Current);
                if (res != 0)
                {
                    return res;
                }
            }

            if (thisEnumerator.MoveNext())
            {
                return 1;
            }

            if (rightEnumerator.MoveNext())
            {
                return -1;
            }

            return 0;
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
