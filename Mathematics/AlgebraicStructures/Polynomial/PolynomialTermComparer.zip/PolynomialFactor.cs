﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mathematics.AlgebraicStructures
{
    internal class PolynomialFactor<T, R> : WithDegreeFactor
        where R : IRing<T>
    {
        private int degree = 1;
        private Polynomial<T, R> polynomial;

        public PolynomialFactor(Polynomial<T, R> polynomial)
        {
            this.polynomial = polynomial;
        }

        public PolynomialFactor(Polynomial<T, R> polynomial, int degree) : this(polynomial)
        {
            this.degree = degree;
        }

        public override int Degree
        {
            get { return degree; }
            set { degree = value; }
        }

        public Polynomial<T, R> Polynomial
        {
            get { return polynomial; }
            set { polynomial = value; }
        }

        public override GenericFactorType FactorType
        {
            get { return GenericFactorType.POLYNOMIAL; }
        }

        public override int Compare(GenericFactor factor)
        {
            int res = base.Compare(factor);
            if (res == 0)
            {
                var innerFactor = factor as PolynomialFactor<T, R>;
                if (innerFactor == null)
                {
                    return 1;
                }

                res = this.polynomial.Compare(innerFactor.polynomial);
            }

            return res;
        }
    }
}
