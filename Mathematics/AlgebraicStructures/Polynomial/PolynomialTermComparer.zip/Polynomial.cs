﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Utilities.Collections;

namespace Mathematics.AlgebraicStructures
{
    public class Polynomial<T, R>
        where R : IRing<T>
    {
        private InsertionSortedCollection<PolynomTerm<T, R>> terms;
        private PolynomialTermComparer<T, R> comparer;
        private R ring;

        public Polynomial(R ring)
        {
            if (this.ring == null)
            {
                throw new ArgumentNullException("ring");
            }

            this.comparer = new PolynomialTermComparer<T, R>();
            this.terms = new InsertionSortedCollection<PolynomTerm<T, R>>(this.comparer);
            this.ring = ring;
        }

        public Polynomial(R ring, T value)
            : this(ring)
        {
            if (value == null)
            {
                throw new ArgumentNullException("value");
            }

            var term = new PolynomTerm<T, R>(ring);
            var coefficientFactor = new CoefficientFactor<T>(value);
            term.Factors.InsertSortElement(coefficientFactor);
            this.terms.InsertSortElement(term);
        }

        public Polynomial(R ring, T value, string variable)
            : this(ring, value)
        {
            if (string.IsNullOrEmpty(variable))
            {
                throw new ArgumentException("Parameter variable can't be null or empty.");
            }

            var textRegex = new Regex("^[a-z,A-z]+$");
            if (!textRegex.IsMatch(variable))
            {
                throw new ArgumentException("Variable is invalid. Can only be letters.");
            }

            var term = new PolynomTerm<T, R>(ring);
            var variableFactor = new VariableFactor(variable);
            var firstTerm = this.terms.First;
            firstTerm.Factors.InsertSortElement(variableFactor);
        }

        /// <summary>
        /// Tries to get the polynomial as a coefficient. The coefficient value
        /// within the argument is updated if function succeeds.
        /// </summary>
        /// <remarks>A polynomial is seen as a coefficient only when it can be
        /// represented by a single number from the associated ring.
        /// </remarks>
        /// <returns>True if function succeeds and false otherwise.</returns>
        internal bool TryGetAsCoefficient(out CoefficientFactor<T> coefficient)
        {
            coefficient = null;
            if (this.terms.Count == 0)
            {
                coefficient = new CoefficientFactor<T>(this.ring.AdditiveUnity);
            }
            else if (this.terms.Count == 1)
            {
                var term = this.terms.First();
                if (term.IsCoefficient)
                {
                    coefficient = new CoefficientFactor<T>(term.Coefficient);
                }
            }

            return false;
        }

        internal bool TryGetAsVariable(out VariableFactor variableFactor)
        {
            variableFactor = null;
            if (this.terms.Count == 1)
            {
                var term = this.terms.First();
                if (term.Factors.Count == 1)
                {
                    var factor = term.Factors.First;
                    if (factor.FactorType == GenericFactorType.VARIABLE)
                    {
                        if (factor.FactorType == GenericFactorType.VARIABLE)
                        {
                            var varFact = factor as VariableFactor;
                            variableFactor = new VariableFactor(varFact.VariableName, varFact.Degree);
                            return true;
                        }
                        else if (factor.FactorType == GenericFactorType.POLYNOMIAL)
                        {
                            var polFactor = factor as PolynomialFactor<T, R>;

                            // TODO
                            return polFactor.Polynomial.TryGetAsVariable(out variableFactor);
                        }
                    }
                }
            }

            return false;
        }

        internal int Compare(Polynomial<T, R> right)
        {
            if (this.terms.Count > right.terms.Count)
            {
                return 1;
            }

            if (this.terms.Count < right.terms.Count)
            {
                return -1;
            }

            var thisEnumerator = this.terms.GetEnumerator();
            var rightEnumerator = right.terms.GetEnumerator();
            while (thisEnumerator.MoveNext() && rightEnumerator.MoveNext())
            {
                var compare = this.comparer.Compare(thisEnumerator.Current, rightEnumerator.Current);
                if (compare != 0)
                {
                    return compare;
                }
            }

            return 0;
        }

        internal void Add(Polynomial<T, R> right)
        {
            foreach (var polynomialTerm in right.terms)
            {
                foreach (var thisTerm in this.terms)
                {
                    if (thisTerm.Compare(polynomialTerm) == 0)
                    {
                    }
                }
            }
        }

        internal void Multiply(Polynomial<T, R> right)
        {
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
