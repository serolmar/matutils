﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mathematics.AlgebraicStructures
{
    internal enum GenericFactorType
    {
        COEFFICIENT,
        VARIABLE,
        POLYNOMIAL
    }

    internal abstract class GenericFactor
    {
        public abstract GenericFactorType FactorType { get; }

        public virtual int Compare(GenericFactor factor)
        {
            if (this.FactorType == GenericFactorType.COEFFICIENT && factor.FactorType != GenericFactorType.COEFFICIENT)
            {
                return 1;
            }

            if (this.FactorType != GenericFactorType.COEFFICIENT && factor.FactorType == GenericFactorType.COEFFICIENT)
            {
                return -1;
            }

            if (this.FactorType == GenericFactorType.VARIABLE && factor.FactorType != GenericFactorType.VARIABLE)
            {
                return 1;
            }

            if (this.FactorType != GenericFactorType.VARIABLE && factor.FactorType == GenericFactorType.VARIABLE)
            {
                return -1;
            }

            if (this.FactorType == GenericFactorType.POLYNOMIAL && factor.FactorType != GenericFactorType.POLYNOMIAL)
            {
                return 1;
            }

            if (this.FactorType != GenericFactorType.POLYNOMIAL && factor.FactorType == GenericFactorType.POLYNOMIAL)
            {
                return -1;
            }

            return 0;
        }
    }

    internal class GenericFactorComparer : IComparer<GenericFactor>
    {
        public int Compare(GenericFactor x, GenericFactor y)
        {
            if (x == null && y == null)
            {
                return 0;
            }

            if (x != null && y == null)
            {
                return 1;
            }

            if (x == null && y != null)
            {
                return -1;
            }

            return x.Compare(y);
        }
    }
}
