﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mathematics.AlgebraicStructures
{
    internal class PolynomialTermComparer<T,R> : Comparer<PolynomTerm<T,R>>
        where R : IRing<T>
    {
        private GenericFactorComparer genericFactorComparer = new GenericFactorComparer();

        public override int Compare(PolynomTerm<T, R> x, PolynomTerm<T, R> y)
        {
            var xEnum = x.Factors.GetEnumerator();
            var yEnum = y.Factors.GetEnumerator();
            while (xEnum.MoveNext())
            {
                if (yEnum.MoveNext())
                {
                    var temp = this.genericFactorComparer.Compare(xEnum.Current, yEnum.Current);
                    if (temp != 0)
                    {
                        return temp;
                    }
                }
                else
                {
                    return 1;
                }
            }

            if (yEnum.MoveNext())
            {
                return -1;
            }

            return 0;
        }
    }
}
