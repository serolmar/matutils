﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mathematics.AlgebraicStructures
{
    internal class CoefficientFactor<T> : GenericFactor
    {
        private T coefficient;

        public CoefficientFactor(T coeff)
        {
            this.coefficient = coeff;
        }

        public override GenericFactorType FactorType
        {
            get
            {
                return GenericFactorType.COEFFICIENT; 
            }
        }

        public T Coefficient
        {
            get
            {
                return this.coefficient;
            }
            set
            {
                this.coefficient = value;
            }
        }

        public override int Compare(GenericFactor factor)
        {
            return base.Compare(factor);
        }
    }
}
